package org.wikipedia.database;

public class UserOptionContentProvider extends AppContentProvider {
}
