package org.wikipedia.database.async;

public final class AsyncConstant {
    public static final int NO_TRANSACTION_ID = 0;
    public static final int NO_TIMESTAMP = 0;

    private AsyncConstant() { }
}
