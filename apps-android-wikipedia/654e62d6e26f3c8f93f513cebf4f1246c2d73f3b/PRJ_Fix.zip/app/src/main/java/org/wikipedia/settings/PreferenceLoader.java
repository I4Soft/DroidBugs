package org.wikipedia.settings;

/*package*/ interface PreferenceLoader {
    void loadPreferences();
}