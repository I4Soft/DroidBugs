package org.wikipedia.test.view;

import android.support.annotation.DrawableRes;

public interface TestImg {
    @DrawableRes int id();
    boolean isNull();
}