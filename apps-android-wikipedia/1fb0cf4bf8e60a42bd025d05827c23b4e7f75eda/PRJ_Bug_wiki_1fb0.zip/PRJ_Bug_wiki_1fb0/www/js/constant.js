module.exports = {
    DARK_STYLE_FILENAME: "file:///android_asset/dark.css"
}