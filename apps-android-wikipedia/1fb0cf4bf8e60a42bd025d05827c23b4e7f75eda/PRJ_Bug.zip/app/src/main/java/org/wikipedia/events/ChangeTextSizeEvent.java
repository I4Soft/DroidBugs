package org.wikipedia.events;

public class ChangeTextSizeEvent {
    public ChangeTextSizeEvent() {
    }
}
