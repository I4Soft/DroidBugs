alter table habits add column reminder_hour integer;
alter table habits add column reminder_min integer;