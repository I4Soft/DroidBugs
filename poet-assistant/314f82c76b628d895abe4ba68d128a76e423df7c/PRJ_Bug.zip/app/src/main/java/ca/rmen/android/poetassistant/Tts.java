/*
 * Copyright (c) 2016 Carmen Alvarez
 *
 * This file is part of Poet Assistant.
 *
 * Poet Assistant is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Poet Assistant is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Poet Assistant.  If not, see <http://www.gnu.org/licenses/>.
 */

package ca.rmen.android.poetassistant;

import java.util.HashMap;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.annotation.Nullable;
import android.util.Log;

import org.greenrobot.eventbus.EventBus;

import ca.rmen.android.poetassistant.settings.Settings;
import ca.rmen.android.poetassistant.settings.SettingsPrefs;
import io.reactivex.Observable;

public class Tts {
    private static final String TAG = Constants.TAG + Tts.class.getSimpleName();

    private static final float MIN_VOICE_PITCH = 0.25f;
    private static final float MIN_VOICE_SPEED = 0.25f;

    private final Context mContext;
    private TextToSpeech mTextToSpeech;
    private int mTtsStatus = TextToSpeech.ERROR;
    private final SettingsPrefs mSettingsPrefs;

    public static class OnTtsInitialized {
        public final int status;

        private OnTtsInitialized(int status) {
            this.status = status;
        }

        @Override
        public String toString() {
            return "OnTtsInitialized{" +
                    "status=" + status +
                    '}';
        }
    }

    public static class OnUtteranceCompleted {
        final String utteranceId;
        final boolean success;

        OnUtteranceCompleted(String utteranceId, boolean success) {
            this.utteranceId = utteranceId;
            this.success = success;
        }

        @Override
        public String toString() {
            return "OnUtteranceCompleted{" +
                    "success=" + success +
                    ", utteranceId='" + utteranceId + '\'' +
                    '}';
        }
    }

    public Tts(Context context, SettingsPrefs settingsPrefs) {
        mContext = context;
        mSettingsPrefs = settingsPrefs;
        PreferenceManager.getDefaultSharedPreferences(context).registerOnSharedPreferenceChangeListener(mTtsPrefsListener);
        init();
    }

    private void init() {
        Log.v(TAG, "init");
        mTextToSpeech = new TextToSpeech(mContext, mInitListener);
        mTextToSpeech.setOnUtteranceProgressListener(mUtteranceListener);
    }

    /**
     * Force a reinitialization of the TextToSpeech.
     * One use case: if the user changed the default engine, a restart is required to get the new list of voices.
     */
    public void restart() {
        Log.v(TAG, "restart");
        shutdown();
        init();
    }

    public int getStatus() {
        return mTtsStatus;
    }

    public boolean isSpeaking() {
        return isReady() && mTextToSpeech.isSpeaking();
    }

    public void speak(String text) {
        if (!isReady()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            speak21(text);
        else
            speak4(text);
    }

    @SuppressWarnings("deprecation")
    private void speak4(String text) {
        HashMap<String, String> map = new HashMap<>();
        map.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, TAG);
        mTextToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, map);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void speak21(String text) {
        mTextToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, TAG);
    }

    public void speakToFile(String text) {
        if (!isReady()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            PoemAudioExport poemAudioExport = new PoemAudioExport(mContext);
            poemAudioExport.speakToFile(mTextToSpeech, text);
        }
    }

    public void stop() {
        if (mTextToSpeech != null) mTextToSpeech.stop();
    }

    private void shutdown() {
        if (mTextToSpeech != null) {
            mTextToSpeech.setOnUtteranceProgressListener(null);
            //noinspection deprecation
            mTextToSpeech.setOnUtteranceCompletedListener(null);
            mTextToSpeech.shutdown();
            mTtsStatus = TextToSpeech.ERROR;
            EventBus.getDefault().removeStickyEvent(OnTtsInitialized.class);
            mTextToSpeech = null;
        }
    }

    private final TextToSpeech.OnInitListener mInitListener = status -> {
        Log.v(TAG, "onInit: status = " + status);
        mTtsStatus = status;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            useVoiceFromSettings();
        }
        if (status == TextToSpeech.SUCCESS) {
            setVoiceSpeedFromSettings();
            setVoicePitchFromSettings();
        }
        EventBus.getDefault().postSticky(new OnTtsInitialized(status));
    };

    // This can't be local or it will be removed from the shared prefs manager!
    @SuppressWarnings("FieldCanBeLocal")
    private final SharedPreferences.OnSharedPreferenceChangeListener mTtsPrefsListener
            = (sharedPreferences, key) -> {
                if (!isReady()) return;
                if (Settings.PREF_VOICE_SPEED.equals(key)) {
                    setVoiceSpeedFromSettings();
                } else if (Settings.PREF_VOICE_PITCH.equals(key)) {
                    setVoicePitchFromSettings();
                } else if (Settings.PREF_VOICE.equals(key)) {
                    useVoiceFromSettings();
                }
            };

    private void useVoiceFromSettings() {
        useVoice(mTextToSpeech, mSettingsPrefs.getVoice());
    }

    private void setVoiceSpeedFromSettings() {
        float speed = ((float) mSettingsPrefs.getVoiceSpeed()) / 100;
        if (speed < MIN_VOICE_SPEED) speed = MIN_VOICE_SPEED;
        mTextToSpeech.setSpeechRate(speed);
    }

    private void setVoicePitchFromSettings() {
        float pitch = ((float) mSettingsPrefs.getVoicePitch()) / 100;
        if (pitch < MIN_VOICE_PITCH) pitch = MIN_VOICE_PITCH;
        mTextToSpeech.setPitch(pitch);
    }

    public TextToSpeech getTextToSpeech() {
        if (isReady()) return mTextToSpeech;
        return null;
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void useVoice(TextToSpeech textToSpeech, @Nullable String voiceId) {
        try {
            if (voiceId == null || Settings.VOICE_SYSTEM.equals(voiceId)) {
                textToSpeech.setVoice(textToSpeech.getDefaultVoice());
                Log.v(TAG, "Using default voice " + textToSpeech.getDefaultVoice());
            } else {
                Observable.fromIterable(textToSpeech.getVoices())
                        .filter(voice ->
                                // The SDK check is here because lint currently ignores @TargetApi in nested lambdas
                                Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && voiceId.equals(voice.getName()))
                        // If the user changed the tts engine in the system settings, we may not find
                        // the previous voice they selected.
                        .first(textToSpeech.getDefaultVoice())
                        .doOnSuccess(voice -> Log.v(TAG, "using selected voice " + voice))
                        .subscribe(textToSpeech::setVoice);
            }
        } catch (Throwable t) {
            // This happens if I choose "SoundAbout TTS" as the preferred engine.
            // That implementation throws a NullPointerException.
            Log.w(TAG, "Couldn't load the tts voices: " + t.getMessage(), t);
        }
    }


    private boolean isReady() {
        return mTextToSpeech != null && mTtsStatus == TextToSpeech.SUCCESS;
    }

    @SuppressWarnings("deprecation")
    private static class UtteranceListener extends UtteranceProgressListener {

        @Override
        public void onStart(String utteranceId) {
        }

        @Override
        public void onDone(String utteranceId) {
            onUtteranceCompleted(utteranceId);
        }

        @Override
        public void onError(String utteranceId) {
            onUtteranceError(utteranceId);
        }

        @Override
        public void onError(String utteranceId, int errorCode) {
            super.onError(utteranceId, errorCode);
            onUtteranceError(utteranceId);
        }

        @Override
        public void onStop(String utteranceId, boolean interrupted) {
            super.onStop(utteranceId, interrupted);
            onUtteranceCompleted(utteranceId);
        }

        private void onUtteranceCompleted(String utteranceId) {
            EventBus.getDefault().post(new OnUtteranceCompleted(utteranceId, true));
        }

        private void onUtteranceError(String utteranceId) {
            EventBus.getDefault().post(new OnUtteranceCompleted(utteranceId, false));
        }
    }

    private final UtteranceListener mUtteranceListener = new UtteranceListener();
}
