package ca.rmen.android.poetassistant.widget;

/**
 * https://code.google.com/p/android/issues/detail?id=23381
 */
public interface HackFor23381 {
    void setWindowFocusWait(boolean shouldWindowFocusWait);
}
