package com.fsck.k9.ui.crypto;


public interface MessageCryptoCallback {
    void onCryptoOperationsFinished(MessageCryptoAnnotations annotations);
}
