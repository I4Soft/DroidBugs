package com.fsck.k9.ui.messageview;


interface ShowPicturesController {
    void notifyMessageContainerContainsPictures(MessageContainerView messageContainerView);
}
