### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead

### Steps to reproduce
1.
2.
3.

### Environment
K-9 Mail version:

Android version:

Account type (IMAP, POP3, WebDAV/Exchange):
