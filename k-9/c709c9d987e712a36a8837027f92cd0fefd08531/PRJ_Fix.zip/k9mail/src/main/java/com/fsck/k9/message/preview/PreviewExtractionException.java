package com.fsck.k9.message.preview;


class PreviewExtractionException extends Exception {
    public PreviewExtractionException(String detailMessage) {
        super(detailMessage);
    }
}
