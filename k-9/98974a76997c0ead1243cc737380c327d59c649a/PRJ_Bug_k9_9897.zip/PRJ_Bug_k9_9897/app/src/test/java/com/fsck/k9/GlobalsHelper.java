package com.fsck.k9;


import android.content.Context;


public class GlobalsHelper {
    public static void setContext(Context context) {
        Globals.setContext(context);
    }
}
