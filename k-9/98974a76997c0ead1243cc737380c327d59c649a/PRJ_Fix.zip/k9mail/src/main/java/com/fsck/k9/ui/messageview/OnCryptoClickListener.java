package com.fsck.k9.ui.messageview;


public interface OnCryptoClickListener {
    void onCryptoClick();
}
