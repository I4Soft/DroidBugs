package org.xbmc.kore.ui.sections.addon;

import android.support.v4.app.Fragment;
import android.view.View;

public abstract class SharedElementFragment extends Fragment {
    public abstract View getSharedElement();
}
