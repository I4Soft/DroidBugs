Resources required for both the local and instrumentation tests.

**Note**: do not put any tests here! Put local tests
that DO NOT need to be executed on an android device in [test](../test). 
Put tests that DO need to run on an android device in [androidTest](../androidTest).
